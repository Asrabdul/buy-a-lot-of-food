const juan = 'juan';
const pedro = 'pedro';

const sayHi = (name) => {
  console.log(`Hello there ${name}`);
};

module.exports = { juan, pedro, sayHi };
